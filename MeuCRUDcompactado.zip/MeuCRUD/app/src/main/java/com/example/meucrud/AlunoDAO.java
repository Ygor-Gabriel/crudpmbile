package com.example.meucrud;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {

    private ConexaoTest conexaoTest;
    private SQLiteDatabase banco;

    public AlunoDAO(Context context){
        conexaoTest = new ConexaoTest(context);
        banco = conexaoTest.getWritableDatabase();
    }
    public long iserir(Aluno aluno){
        ContentValues values = new ContentValues();
        values.put("nome", aluno.getNome());
        values.put("matricula", aluno.getMatricula());
        values.put("telefone", aluno.getTelefone());
        return banco.insert("aluno",null, values);
    }
    public  List <Aluno> listarTodos(){
        List<Aluno> alunos = new ArrayList<>();
        Cursor cursor = banco.query("aluno", new String[]{"id","nome","matricula","telefone"},
        null, null, null, null, null);
        while (cursor.moveToNext()){
            Aluno a = new Aluno();
            a.setId(cursor.getInt(0));
            a.setNome(cursor.getString(1));
            a.setMatricula(cursor.getString(2));
            a.setTelefone(cursor.getString(3));
            alunos.add(a);
        }
        return alunos;
    }

}
