package com.example.meucrud;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexaoTest extends SQLiteOpenHelper {

    private static final String name ="banco.db";
    private static final int version = 1;

    public ConexaoTest(@Nullable Context context) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table aluno(id interger primary key autoincrement," +
                "nome varchar(50), matricula varchar(12), telefone varchar(13))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}